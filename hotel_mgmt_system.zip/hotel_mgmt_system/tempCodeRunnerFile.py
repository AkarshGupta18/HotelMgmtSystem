def forgot_password_window(self):
        if self.email_entry.get()=="":
            messagebox.showerror("Error","Enter email address")
        else:
            conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
            my_cusror=conn.cursor()
            query=("SELECT * from register WHERE email=%s")
            value=(self.email_entry.get)