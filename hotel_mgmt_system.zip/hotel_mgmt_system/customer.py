from tkinter import*
from PIL import Image,ImageTk,ImageOps
import requests
from io import BytesIO
from tkinter import ttk #for stylish entry field
import random
import mysql.connector
from tkinter import messagebox

class Cust_Win:
    def __init__(self,root) :
        self.root=root
        self.root.title("Hotel Management System")
        self.root.geometry("1295x550+230+220") #+ these tell from where(which position) the window should open
        #====variables=====#
        self.var_ref=StringVar()
        x=random.randint(1000,9999)
        self.var_ref.set(str(x))
        
        #StringVar is a special variable class provided by Tkinter that allows you to manage string variables dynamically.
        self.var_cust_name=StringVar()
        self.var_mother=StringVar()
        self.var_gender=StringVar()
        self.var_post=StringVar()
        self.var_mobile=StringVar()
        self.var_email=StringVar()
        self.var_nationality=StringVar()
        self.var_address=StringVar()
        self.var_id_proof=StringVar()
        self.var_id_number=StringVar()




        #=====TITLE=====#
        lbl_title=Label(self.root,text="Add Customer Details",font=("times new roman",18,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE)
        lbl_title.place(x=0,y=0,width=1295,height=50)


        #=====Logo======#
        url2 = 'https://static.wikia.nocookie.net/staypedia/images/1/1c/Taj_Hotels_logo.png/revision/latest/thumbnail/width/360/height/360?cb=20200214185939'  
        response = requests.get(url2)
        img_data = response.content
        img = Image.open(BytesIO(img_data))
        width, height = 100,40 
        img = img.resize((width, height), Image.Resampling.LANCZOS)
        border_width = 2
        border_color = "silver"
        img = ImageOps.expand(img, border=border_width, fill=border_color)
        img2 = ImageTk.PhotoImage(img)
        labelImage = Label(self.root, image=img2)
        labelImage.img2 = img2  
        labelImage.place(x=5, y=2, width=width + 2 * border_width, height=height + 2 * border_width)  # Place the image

        #=====Label Frame=====#
        labelFrameLeft=LabelFrame(self.root,bd=2,relief=RIDGE,text="Customer Details",font=("times new roman",12,"bold"),padx=2)
        labelFrameLeft.place(x=5,y=50,width=425,height=490)

        #=====Labels and entries=====#

        #cust ref
        lbl_cust_ref=Label(labelFrameLeft,text=" Ref No:",font=("arial",12,"bold"),padx=2,pady=6)
        lbl_cust_ref.grid(row=0,column=0,sticky=W)
        entry_ref=ttk.Entry(labelFrameLeft,textvariable=self.var_ref,width=29,font=("arial",13,"bold"),state="readonly") # we add texvariable to bind the entry widget to a Tkinter variable,like an instance of StringVar, IntVar, DoubleVar, or BooleanVar.
        # When we bind StringVar to an entry widget using textvariable, any changes to the variable will automatically update the content of the entry widget, and vice versa.
        entry_ref.grid(row=0,column=1)

        #Cust name
        cname=Label(labelFrameLeft,text="Customer Name:",font=("arial",12,"bold"),padx=2,pady=6)
        cname.grid(row=1,column=0,sticky=W)
        txtcname=ttk.Entry(labelFrameLeft,textvariable=self.var_cust_name,width=29,font=("arial",13,"bold"))
        txtcname.grid(row=1,column=1)

        #mother name
        lblmname=Label(labelFrameLeft,text="Mother Name:",font=("arial",12,"bold"),padx=2,pady=6)
        lblmname.grid(row=2,column=0,sticky=W)
        txtmname=ttk.Entry(labelFrameLeft,textvariable=self.var_mother,width=29,font=("arial",13,"bold"))
        txtmname.grid(row=2,column=1)

        #gender combobox
        label_gender=Label(labelFrameLeft,text="Gender:",font=("arial",12,"bold"),padx=2,pady=6)
        label_gender.grid(row=3,column=0,sticky=W)
        combo_gender=ttk.Combobox(labelFrameLeft,textvariable=self.var_gender,font=("arial",12,"bold"),width=27,state="readonly")
        combo_gender["value"]=("Male","Female","Other")
        combo_gender.current(0) #want 0th index element to be displayed as default
        combo_gender.grid(row=3,column=1)

        #Postcode
        lblPostCode=Label(labelFrameLeft,text="Post Code:",font=("arial",12,"bold"),padx=2,pady=6)
        lblPostCode.grid(row=4,column=0,sticky=W)
        txtPostCode=ttk.Entry(labelFrameLeft,textvariable=self.var_post,width=29,font=("arial",13,"bold"))
        txtPostCode.grid(row=4,column=1)

        #Mobile number
        lblMobile=Label(labelFrameLeft,text="Mobile Number:",font=("arial",12,"bold"),padx=2,pady=6)
        lblMobile.grid(row=5,column=0,sticky=W)
        txtMobile=ttk.Entry(labelFrameLeft,textvariable=self.var_mobile,width=29,font=("arial",13,"bold"))
        txtMobile.grid(row=5,column=1)

        #Email
        lblEmail=Label(labelFrameLeft,text="Email:",font=("arial",12,"bold"),padx=2,pady=6)
        lblEmail.grid(row=6,column=0,sticky=W)
        txtEmail=ttk.Entry(labelFrameLeft,textvariable=self.var_email,width=29,font=("arial",13,"bold"))
        txtEmail.grid(row=6,column=1)

        #Nationality
        lblNationality=Label(labelFrameLeft,text="Nationality:",font=("arial",12,"bold"),padx=2,pady=6)
        lblNationality.grid(row=7,column=0,sticky=W)

        combo_Nationality=ttk.Combobox(labelFrameLeft,textvariable=self.var_nationality,font=("arial",12,"bold"),width=27,state="readonly")
        combo_Nationality["value"]=("Indian","Japanese","Russian","American","Other")
        combo_Nationality.current(0) #want 0th index element to be displayed as default
        combo_Nationality.grid(row=7,column=1)

        #id proof type
        lblProof=Label(labelFrameLeft,text="Id Proof:",font=("arial",12,"bold"),padx=2,pady=6)
        lblProof.grid(row=8,column=0,sticky=W)

        combo_id=ttk.Combobox(labelFrameLeft,textvariable=self.var_id_proof,font=("arial",12,"bold"),width=27,state="readonly")
        combo_id["value"]=("Aadhar","Driving License","Passport","Voter's id")
        combo_id.current(0) #want 0th index element to be displayed as default
        combo_id.grid(row=8,column=1)

        #id number
        lblIdNumber=Label(labelFrameLeft,text="Id Number:",font=("arial",12,"bold"),padx=2,pady=6)
        lblIdNumber.grid(row=9,column=0,sticky=W)
        txtIdNumber=ttk.Entry(labelFrameLeft,textvariable=self.var_id_number,width=29,font=("arial",13,"bold"))
        txtIdNumber.grid(row=9,column=1)

        #Address
        lblAddress=Label(labelFrameLeft,text="Address:",font=("arial",12,"bold"),padx=2,pady=6)
        lblAddress.grid(row=9,column=0,sticky=W)
        txtAddress=ttk.Entry(labelFrameLeft,textvariable=self.var_address,width=29,font=("arial",13,"bold"))
        txtAddress.grid(row=9,column=1)
        

        #=======frame inside which Button==========#
        btn_frame=Frame(labelFrameLeft,bd=2,relief=RIDGE)
        btn_frame.place(x=0,y=400,width=412,height=40)

        btnAdd=Button(btn_frame,text="Add",font=("arial",12,"bold"),bg="black",fg="gold",width=9,command=self.add_data)
        btnAdd.grid(row=0,column=0,padx=1)

        btnUpdate=Button(btn_frame,text="Update",font=("arial",12,"bold"),bg="black",fg="gold",width=9,command=self.update)
        btnUpdate.grid(row=0,column=1,padx=1)

        btnDelete=Button(btn_frame,text="Delete",font=("arial",12,"bold"),bg="black",fg="gold",width=9,command=self.mDelete)
        btnDelete.grid(row=0,column=2,padx=1)

        btnReset=Button(btn_frame,text="Reset",font=("arial",12,"bold"),bg="black",fg="gold",width=9,command=self.reset)
        btnReset.grid(row=0,column=3,padx=1)
        
        #=======Table frame search system======#
        Table_Frame=LabelFrame(self.root,bd=2,relief=RIDGE,text="View details and search system",font=("times new roman",12,"bold"),padx=2)
        Table_Frame.place(x=435,y=50,width=860,height=450)

        lblSearchBy=Label(Table_Frame,text="Search By:",font=("arial",12,"bold"),bg="red",fg="white")
        lblSearchBy.grid(row=0,column=0,sticky=W)

        self.search_var=StringVar()

        combo_Search=ttk.Combobox(Table_Frame,font=("arial",12,"bold"),width=24,state="readonly",textvariable=self.search_var)
        combo_Search["value"]=("Mobile","Ref")
        combo_Search.current(0) #want 0th index element to be displayed as default
        combo_Search.grid(row=0,column=1,padx=2)
        
        self.mob_search=StringVar()
        txtMob=ttk.Entry(Table_Frame,width=24,font=("arial",13,"bold"),textvariable=self.mob_search)
        txtMob.grid(row=0,column=2,padx=2)


        btnSearch=Button(Table_Frame,text="Search",font=("arial",11,"bold"),bg="black",fg="gold",width=10,command=self.search)
        btnSearch.grid(row=0,column=3,padx=1)

        btnShowAll=Button(Table_Frame,text="Show all",font=("arial",11,"bold"),bg="black",fg="gold",width=10,command=self.fetch_data)
        btnShowAll.grid(row=0,column=4,padx=1)


        #======Show data table=======#

        details_table=Frame(Table_Frame,bd=2,relief=RIDGE)
        details_table.place(x=0,y=50,width=860,height=350)

        scroll_x=Scrollbar(details_table,orient=HORIZONTAL)
        scroll_y=Scrollbar(details_table,orient=VERTICAL)

        self.Cust_Details_Table=ttk.Treeview(details_table,column=("ref","name","mother","gender","post","mobile","email","nationality","idproof","idnumber","address"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set) #just a variable to access local instances

        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_x.config(command=self.Cust_Details_Table.xview)
        scroll_y.config(command=self.Cust_Details_Table.yview)

        self.Cust_Details_Table.heading("ref",text="Ref no.")
        self.Cust_Details_Table.heading("name",text="Name")
        self.Cust_Details_Table.heading("mother",text="Mother name")
        self.Cust_Details_Table.heading("gender",text="Gender")
        self.Cust_Details_Table.heading("post",text="Post code")
        self.Cust_Details_Table.heading("mobile",text="Mobile no.")
        self.Cust_Details_Table.heading("email",text="Email")
        self.Cust_Details_Table.heading("nationality",text="Nationality")
        self.Cust_Details_Table.heading("idproof",text="Id proof")
        self.Cust_Details_Table.heading("idnumber",text="Id no.")
        self.Cust_Details_Table.heading("address",text="Address")
        
        #to set column width of each
        self.Cust_Details_Table.column("ref",width=80)
        self.Cust_Details_Table.column("name",width=80)
        self.Cust_Details_Table.column("mother",width=80)
        self.Cust_Details_Table.column("gender",width=80)
        self.Cust_Details_Table.column("post",width=80)
        self.Cust_Details_Table.column("mobile",width=80)
        self.Cust_Details_Table.column("email",width=80)
        self.Cust_Details_Table.column("nationality",width=80)
        self.Cust_Details_Table.column("idproof",width=80)
        self.Cust_Details_Table.column("idnumber",width=80)
        self.Cust_Details_Table.column("address",width=80)
        
        #to display heading on the screen
        self.Cust_Details_Table["show"]="headings"
        self.Cust_Details_Table.pack(fill=BOTH,expand=1)
        self.Cust_Details_Table.bind("<ButtonRelease-1>",self.get_cursor)
        #This line binds the <ButtonRelease-1> event (left mouse button being released) to the get_cursor method. This means that whenever you click on a row in the Cust_Details_Table, the get_cursor method will be called.
        self.fetch_data()

    def add_data(self):
        if self.var_mobile.get()=="" or self.var_mother.get()=="":
            messagebox.showerror("Error! All fields required.")
        else:
            try:
                conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
                my_cusror=conn.cursor()
                my_cusror.execute("Insert into customer values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(self.var_ref.get(),self.var_cust_name.get(),self.var_mother.get(),self.var_gender.get(),self.var_post.get(),self.var_mobile.get(),self.var_email.get(),self.var_nationality.get(),self.var_id_proof.get(),self.var_id_number.get(),self.var_address.get()))
                
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success","Customer has been added",parent=self.root)
             #we want message box to show in this window only,so we use parent=self.root..otherwise it will open in other window
            except Exception as es:
                messagebox.showwarning("Warning",f"Something went wrong:{str(es)}",parent=self.root)
  

    def fetch_data(self):
        conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
        my_cusror=conn.cursor()
        my_cusror.execute("select * from customer") #display table
        rows=my_cusror.fetchall()
        if len(rows)!=0:
            self.Cust_Details_Table.delete(*self.Cust_Details_Table.get_children()) #delete exisitng data and then add new data,clear TreeView of old data
            for i in rows:
                self.Cust_Details_Table.insert("",END,values=i)
            conn.commit()
        conn.close()
    
    def get_cursor(self,event=""):
        cursor_row=self.Cust_Details_Table.focus()
        content=self.Cust_Details_Table.item(cursor_row)
        row=content["values"]

        self.var_ref.set(row[0]),
        self.var_cust_name.set(row[1]),
        self.var_mother.set(row[2]),
        self.var_gender.set(row[3]),
        self.var_post.set(row[4]),
        self.var_mobile.set(row[5]),
        self.var_email.set(row[6]),
        self.var_nationality.set(row[7]),
        self.var_id_proof.set(row[8]),
        self.var_id_number.set(row[9]),
        self.var_address.set(row[10])
        #These lines set the values of various StringVar instances (self.var_ref, self.var_cust_name, etc.) to the corresponding values from the selected row. This effectively updates the form fields with the data from the selected row in the table.
    
    def update(self):
        if self.var_mobile=="":
            messagebox.showerror("Error,mobile number not found",parent=self.root)
        else:   
            conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
            my_cusror=conn.cursor()
            my_cusror.execute("update customer set name=%s,mother=%s,gender=%s,post=%s,mobile=%s,email=%s,nationality=%s,idproof=%s,idnumber=%s,address=%s where ref=%s",(self.var_cust_name.get(),self.var_mother.get(),self.var_gender.get(),self.var_post.get(),self.var_mobile.get(),self.var_email.get(),self.var_nationality.get(),self.var_id_proof.get(),self.var_id_number.get(),self.var_address.get(),self.var_ref.get())) #columns names as in mysql table

            conn.commit()
            self.fetch_data()
            messagebox.showinfo("Update","Customer details have been updated successfully.",parent=self.root)
            conn.close()

    def mDelete(self):
        mDelete=messagebox.askyesno("Hotel management system","Do you want to delete this customer?",parent=self.root)
        if mDelete>0:
            conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
            my_cusror=conn.cursor()
            query="delete from customer where ref=%s"
            value=(self.var_ref.get(),)
            my_cusror.execute(query,value)
        else:
            if not mDelete:
                return
        conn.commit()
        self.fetch_data()
        conn.close()

    def reset(self):
            #self.var_ref.set(""),
            self.var_cust_name.set(""),
            self.var_mother.set(""),
            #self.var_gender.set(""),
            self.var_post.set(""),
            self.var_mobile.set(""),
            self.var_email.set(""),
            #self.var_nationality.set(""),
            #self.var_id_proof.set(""),
            self.var_id_number.set(""),
            self.var_address.set("")

            x=random.randint(1000,9999)
            self.var_ref.set(str(x))  #if i click on update,i want a new reference number

    def search(self):
        conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
        my_cusror=conn.cursor()
        my_cusror.execute("select * from customer where "+str(self.search_var.get())+"LIKE '%s" + str(self.mob_search.get()) + "%'")
        rows=my_cusror.fetchall()
        if len(rows)!=0:
            self.Cust_Details_Table.delete(*self.Cust_Details_Table.get_children())
            for i in rows:
                self.Cust_Details_Table.insert("",END,values=i)
            conn.commit()
        conn.close()    


if __name__=="__main__":
    root=Tk()
    obj=Cust_Win(root)
    root.mainloop()


