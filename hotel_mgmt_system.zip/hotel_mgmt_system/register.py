from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk,ImageOps
import requests
from io import BytesIO
from tkinter import ttk #for stylish entry field
import random
import tkinter as tk
from datetime import datetime
from tkinter import messagebox
import mysql.connector

class Register:
    def __init__(self,root):
        self.root=root #name of window
        self.root.title("Register")
        self.root.geometry("1600x900+0+0")
        
        #==========variables==========#
        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_contact=StringVar()
        self.var_email=StringVar()
        self.var_securityQ=StringVar()
        self.var_securityA=StringVar()
        self.var_pass=StringVar()
        self.var_confpass=StringVar()

         #===background image======#
        url='https://images.rawpixel.com/image_social_landscape/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTA1L3Y5MDYtZ2liLTAwMjMuanBn.jpg'
        response = requests.get(url)
        img_data = response.content
        self.img = Image.open(BytesIO(img_data))
        # Resize image to fit the initial window size
        img_resized = self.img.resize((self.root.winfo_screenwidth(), self.root.winfo_screenheight()), Image.Resampling.LANCZOS)
        self.img_tk = ImageTk.PhotoImage(img_resized)  # Store it as an instance variable
        self.lbl_bg = tk.Label(self.root, image=self.img_tk)
        self.lbl_bg.place(x=0, y=0, relwidth=1, relheight=1)
        # Update image size dynamically to fit the window
        self.root.bind("<Configure>", self.resize_image) 


        #=====Left image======#
        url2 = 'https://i.pinimg.com/originals/e2/51/59/e25159f54c8d8c761ef20d57ef9bf93f.png'  
        response = requests.get(url2)
        img_data = response.content
        img = Image.open(BytesIO(img_data))
        width, height = 470,550
        img = img.resize((width, height), Image.Resampling.LANCZOS)
        border_width = 1
        border_color = "white"
        img = ImageOps.expand(img, border=border_width, fill=border_color)
        img2 = ImageTk.PhotoImage(img)
        labelImage = Label(self.root, image=img2)
        labelImage.img2 = img2  
        labelImage.place(x=50, y=100)

        #===main fram====#
        frame=Frame(self.root,bg="white")
        frame.place(x=520,y=100,width=800,height=552)

        register_lbl=Label(frame,text="SIGN UP",font=("times new roman",20,"bold"),fg="darkgreen",bg="white")
        register_lbl.place(x=20,y=20)

        #===Label and entries====#

        #Row 1
        fname_lbl=Label(frame,text="First name",font=("times new roman",15,"bold"),bg="white")
        fname_lbl.place(x=50,y=100)
    
        self.fname_entry=ttk.Entry(frame,font=("arial",15,"bold"),textvariable=self.var_fname) 
        self.fname_entry.place(x=50,y=130,width=250)

        lname_lbl=Label(frame,text="Last name",font=("times new roman",15,"bold"),bg="white")
        lname_lbl.place(x=370,y=100)

        self.lname_entry=ttk.Entry(frame,font=("arial",15,"bold"),textvariable=self.var_lname) 
        self.lname_entry.place(x=370,y=130,width=250)

        #Row 2
        contact_lbl=Label(frame,text="Contact No.",font=("times new roman",15,"bold"),bg="white",fg='black')
        contact_lbl.place(x=50,y=170)
    
        self.contact_entry=ttk.Entry(frame,font=("arial",15,"bold"),textvariable=self.var_contact) 
        self.contact_entry.place(x=50,y=200,width=250)

        email_lbl=Label(frame,text="Email",font=("times new roman",15,"bold"),bg="white",fg="black")
        email_lbl.place(x=370,y=170)

        self.email_entry=ttk.Entry(frame,font=("arial",15,"bold"),textvariable=self.var_email) 
        self.email_entry.place(x=370,y=200,width=250)

        #Row 3
        securityQ_lbl=Label(frame,text="Contact No.",font=("times new roman",15,"bold"),bg="white",fg='black')
        securityQ_lbl.place(x=50,y=170)
    
        self.combo_SecurityQ=ttk.Combobox(frame,font=("arial",15,"bold"),state="readonly",textvariable=self.var_securityQ)
        self.combo_SecurityQ["value"]=("Select","Your birth place","your nickname")
        self.combo_SecurityQ.current(0) 
        self.combo_SecurityQ.place(x=50,y=270,width=250)

        securityAns_lbl=Label(frame,text="Security answer",font=("times new roman",15,"bold"),bg="white",fg="black")
        securityAns_lbl.place(x=370,y=240)

        self.securityAns_entry=ttk.Entry(frame,font=("arial",15,"bold"),textvariable=self.var_securityA) 
        self.securityAns_entry.place(x=370,y=270,width=250)

        #Row 4
        pswd_lbl=Label(frame,text="Enter new password",font=("times new roman",15,"bold"),bg="white",fg='black')
        pswd_lbl.place(x=50,y=310)
    
        self.pswd_entry=ttk.Entry(frame,font=("arial",15,"bold"),textvariable=self.var_pass) 
        self.pswd_entry.place(x=50,y=340,width=250)

        confirmPswd_lbl=Label(frame,text="Confirm password",font=("times new roman",15,"bold"),bg="white",fg="black")
        confirmPswd_lbl.place(x=370,y=310)

        self.confirmPswd_entry=ttk.Entry(frame,font=("arial",15,"bold"),textvariable=self.var_confpass) 
        self.confirmPswd_entry.place(x=370,y=340,width=250)

        #===Check Btn====#
        self.var_check=IntVar() #as its value is either 0 or 1
        checkBtn=Checkbutton(frame,variable=self.var_check,text="I agree to terms and conditions",font=("times new roman",15,"bold"),onvalue=1,offvalue=0)
        checkBtn.place(x=50,y=380)

        #===Button image sign up======#
        
        url3 = 'https://freepngimg.com/convert-png/24743-sign-up-button-transparent'
        response = requests.get(url3)
        img_data = response.content
        img = Image.open(BytesIO(img_data))
        width, height = 120, 50
        img = img.resize((width, height), Image.Resampling.LANCZOS)
        border_width = 1
        border_color = "white"
        img = ImageOps.expand(img, border=border_width, fill=border_color)
        self.img_button = ImageTk.PhotoImage(img)

        b1 = Button(frame, image=self.img_button, borderwidth=0, cursor="hand2",command=self.register_data)
        b1.place(x=50, y=440)

         #===Button image login in======#
        
        url4 = 'https://strathostess.co.za/wp-content/uploads/2016/11/login-button-blue-i8.jpg'
        response = requests.get(url4)
        img_data = response.content
        img1 = Image.open(BytesIO(img_data))
        width, height = 150, 50
        img1 = img1.resize((width, height), Image.Resampling.LANCZOS)
        border_width = 1
        border_color = "white"
        img1 = ImageOps.expand(img1, border=border_width, fill=border_color)
        self.img_button1 = ImageTk.PhotoImage(img1)

        b2 = Button(frame, image=self.img_button1, borderwidth=0, cursor="hand2")
        b2.place(x=200, y=440)


    def register_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_securityQ.get()=="Select":
            messagebox.showerror("Error!","All fields are required.")
        elif(self.var_pass.get()!=self.var_confpass.get()):
            messagebox.showerror("Error","Confirm password must be same as password.")
        elif(self.var_check.get()==0):
            messagebox.showerror("Invalid","Please agree to terms and conditions.")
        else:
            conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
            my_cusror=conn.cursor()
            query=("SELECT * from register where email=%s")
            value=(self.var_email.get(),)
            my_cusror.execute(query,value)
            row=my_cusror.fetchone()

            if(row!=None):
                 messagebox.showerror("Invalid","User already exists,try different email")
            else:
                my_cusror.execute("insert into register values(%s,%s,%s,%s,%s,%s,%s)",(self.var_fname.get(),self.var_lname.get(),self.var_contact.get(),self.var_email.get(),self.var_securityQ.get(),self.var_securityA.get(),self.var_pass.get()))

                conn.commit()
                conn.close()
                messagebox.showinfo("Success","Registered successfully")

  

        






         





    def resize_image(self, event):
        new_width = event.width
        new_height = event.height
        img_resized = self.img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        self.img_tk = ImageTk.PhotoImage(img_resized)  # Update instance variable
        self.lbl_bg.config(image=self.img_tk)
        self.lbl_bg.image = self.img_tk

if __name__=="__main__":
    root=Tk()
    obj=Register(root)
    root.mainloop()
