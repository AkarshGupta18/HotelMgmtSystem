from tkinter import*
from PIL import Image,ImageTk,ImageOps
import requests
from io import BytesIO
from tkinter import ttk #for stylish entry field
import random
import mysql.connector
from tkinter import messagebox

class DetailsRoom:
    def __init__(self,root) :
        self.root=root
        self.root.title("Hotel Management System")
        self.root.geometry("1295x550+230+220")
        
         #=====TITLE=====#
        lbl_title=Label(self.root,text="Room Booking",font=("times new roman",18,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE)
        lbl_title.place(x=0,y=0,width=1295,height=50)


        #=====Logo======#
        url2 = 'https://static.wikia.nocookie.net/staypedia/images/1/1c/Taj_Hotels_logo.png/revision/latest/thumbnail/width/360/height/360?cb=20200214185939'  
        response = requests.get(url2)
        img_data = response.content
        img = Image.open(BytesIO(img_data))
        width, height = 100,40 
        img = img.resize((width, height), Image.Resampling.LANCZOS)
        border_width = 2
        border_color = "silver"
        img = ImageOps.expand(img, border=border_width, fill=border_color)
        img2 = ImageTk.PhotoImage(img)
        labelImage = Label(self.root, image=img2)
        labelImage.img2 = img2  
        labelImage.place(x=5, y=2, width=width + 2 * border_width, height=height + 2 * border_width)

        #=====Label Frame=====#
        labelFrameLeft=LabelFrame(self.root,bd=2,relief=RIDGE,text="New room add",font=("times new roman",12,"bold"),padx=2)
        labelFrameLeft.place(x=5,y=50,width=540,height=350)

        #=====Labels and entries=====#
        
        #Floor
        self.var_floor=StringVar()

        lbl_floor=Label(labelFrameLeft,text="Floor ",font=("arial",12,"bold"),padx=2,pady=6)
        lbl_floor.grid(row=0,column=0,sticky=W)

        entry_floor=ttk.Entry(labelFrameLeft,width=29,font=("arial",13,"bold"),textvariable=self.var_floor) 
        entry_floor.grid(row=0,column=1,sticky=W)

        #Room No
        self.var_roomNo=StringVar()

        lbl_RoomNo=Label(labelFrameLeft,text="Room No. ",font=("arial",12,"bold"),padx=2,pady=6)
        lbl_RoomNo.grid(row=1,column=0,sticky=W)

        entry_RoomNo=ttk.Entry(labelFrameLeft,width=29,font=("arial",13,"bold"),textvariable=self.var_roomNo) 
        entry_RoomNo.grid(row=1,column=1,sticky=W)

        #Room type
        self.var_RoomType=StringVar()

        lbl_RoomType=Label(labelFrameLeft,text="Room type ",font=("arial",12,"bold"),padx=2,pady=6)
        lbl_RoomType.grid(row=2,column=0,sticky=W)

        entry_Roomlbl_RoomType=ttk.Combobox(labelFrameLeft,font=("arial",13,"bold"),state="readonly",textvariable=self.var_RoomType)
        entry_Roomlbl_RoomType["value"]=("Select","Single","Double","Delux")
        entry_Roomlbl_RoomType.current(0)
        entry_Roomlbl_RoomType.grid(row=2,column=1,sticky=W)

        #====Btns=======#
        btn_frame=Frame(labelFrameLeft,bd=2,relief=RIDGE)
        btn_frame.place(x=0,y=200,width=412,height=40)

        btnAdd=Button(btn_frame,text="Add",font=("arial",12,"bold"),bg="black",fg="gold",width=9,command=self.add_data)
        btnAdd.grid(row=0,column=0,padx=1)

        btnUpdate=Button(btn_frame,text="Update",font=("arial",12,"bold"),bg="black",fg="gold",width=9,command=self.update)
        btnUpdate.grid(row=0,column=1,padx=1)

        btnDelete=Button(btn_frame,text="Delete",font=("arial",12,"bold"),bg="black",fg="gold",width=9,command=self.mDelete)
        btnDelete.grid(row=0,column=2,padx=1)

        btnReset=Button(btn_frame,text="Reset",font=("arial",12,"bold"),bg="black",fg="gold",width=9,command=self.reset)
        btnReset.grid(row=0,column=3,padx=1)

         #=======Table frame search system======#
        Table_Frame=LabelFrame(self.root,bd=2,relief=RIDGE,text="Show room details",font=("times new roman",12,"bold"),padx=2)
        Table_Frame.place(x=600,y=55,width=600,height=350)
        
        scroll_x=Scrollbar(Table_Frame,orient=HORIZONTAL)
        scroll_y=Scrollbar(Table_Frame,orient=VERTICAL)

        self.room_table=ttk.Treeview(Table_Frame,column=("Floor","RoomNo","RoomType"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set) #just a variable to access local instances

        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_x.config(command=self.room_table.xview)
        scroll_y.config(command=self.room_table.yview)

        self.room_table.heading("Floor",text="Floor")
        self.room_table.heading("RoomNo",text="Room No.")
        self.room_table.heading("RoomType",text="Room type")

        self.room_table["show"]="headings"
        
        #to set column width of each
        self.room_table.column("Floor",width=80)
        self.room_table.column("RoomNo",width=80)
        self.room_table.column("RoomType",width=80)
    
        #to display heading on the screen
        self.room_table["show"]="headings"
        self.room_table.pack(fill=BOTH,expand=1)
        self.room_table.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()

    def add_data(self):
        if self.var_floor.get()=="" or self.var_RoomType.get()=="":
            messagebox.showerror("Error! All fields required.",parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
                my_cusror=conn.cursor()
                my_cusror.execute("insert into details values(%s,%s,%s)",(self.var_floor.get(),self.var_roomNo.get(),self.var_RoomType.get()))
                
                conn.commit()
                self.fetch_data() #n the add_data function, the fetch_data function is called after inserting a new record into the database. fetch_data function is called to retrieve the latest data from the room table.The fetch_data function fetches all records from the room table and updates the TreeView widget in your Tkinter application

                conn.close()
                messagebox.showinfo("Success","New room has been added",parent=self.root)
             #we want message box to show in this window only,so we use parent=self.root..otherwise it will open in other window
            except Exception as es:
                messagebox.showwarning("Warning",f"Something went wrong:{str(es)}",parent=self.root)

     #==fetch data from mysql to tkinter window
    def fetch_data(self):
        conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
        my_cusror=conn.cursor()
        my_cusror.execute("select * from details") #display table
        rows=my_cusror.fetchall()
        if len(rows)!=0:
            self.room_table.delete(*self.room_table.get_children()) #delete exisitng data and then add new data,clear TreeView of old data
            for i in rows:
                self.room_table.insert("",END,values=i)
            conn.commit()
        conn.close()

    def get_cursor(self,event=""):
        cursor_row=self.room_table.focus()
        content=self.room_table.item(cursor_row)
        row=content["values"]

        self.var_floor.set(row[0]),
        self.var_roomNo.set(row[1]),
        self.var_RoomType.set(row[2]),

    def update(self):
        if self.var_floor.get()=="":
            messagebox.showerror("Error,Please enter floor number",parent=self.root)
        else:   
            conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
            my_cusror=conn.cursor()
            my_cusror.execute("UPDATE details SET Floor=%s,RoomType=%s WHERE RoomNo=%s",(self.var_floor.get(),self.var_RoomType.get(),self.var_roomNo.get()))#columns names as in mysql table

            conn.commit()
            self.fetch_data()
            messagebox.showinfo("Update","Room details have been updated successfully.",parent=self.root)
            conn.close()
        
    def mDelete(self):
        mDelete=messagebox.askyesno("Hotel management system","Do you want to delete this room details?",parent=self.root)
        if mDelete>0:
            conn=mysql.connector.connect(host="localhost",username="root",password="mysql@123",database="hotel_management_system")
            my_cusror=conn.cursor()
            query="delete from details where RoomNo=%s"
            value=(self.var_roomNo.get(),)
            my_cusror.execute(query,value)
        else:
            if not mDelete:
                return
        conn.commit()
        self.fetch_data()
        conn.close()

    def reset(self):
            self.var_floor(""),
            self.var_roomNo.set(""),
            self.var_RoomType.set(""),
            
       

if __name__=="__main__":
    root=Tk()
    obj=DetailsRoom(root)
    root.mainloop()